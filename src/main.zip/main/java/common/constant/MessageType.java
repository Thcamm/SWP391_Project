package common.constant;

public enum MessageType {
    SUCCESS,
    ERROR,
    WARNING,
    INFO,
    INLINE,
    VALIDATION
}
