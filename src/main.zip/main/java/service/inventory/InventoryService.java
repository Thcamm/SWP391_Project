package service.inventory;

public class InventoryService {
}
