package service.notification;

public class NotificationService {
}
