package service.diagnostic;

public class DiagnosticService {
}
