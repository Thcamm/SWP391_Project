package controller.employee.customerservice;

public class ViewCustomerDetail {
}
