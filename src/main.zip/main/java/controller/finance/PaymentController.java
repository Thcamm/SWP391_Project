package controller.finance;

public class PaymentController {
}
