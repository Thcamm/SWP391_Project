package controller.finance;

public class InvoiceController {
}
