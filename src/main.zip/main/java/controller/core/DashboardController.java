package controller.core;

public class DashboardController {
}
