package model.employee.admin.rbac;

public class MenuItem {
    public int menuId;
    public String label;
    public String path;
    public String icon;
    public int orderNo;
    public Integer parentId;
    public Integer permId;
}
