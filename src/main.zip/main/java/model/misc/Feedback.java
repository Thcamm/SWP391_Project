package model.misc;

public class Feedback {
}
