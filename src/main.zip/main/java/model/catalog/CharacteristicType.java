package model.catalog;

public class CharacteristicType {
}
