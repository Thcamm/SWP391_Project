package model.catalog;

public class PartDetail {
}
