package model.catalog;

public class Part {
}
