package model.catalog;

public class Unit {
}
