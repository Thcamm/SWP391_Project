package model.catalog;

public class CharacteristicValue {
}
